import "./intro.css"

export default function Intro() {
  return (
    <div className='intro' id="intro">
      Thanushan Pirapakaran's Portfolio Website
    </div>
  )
}
